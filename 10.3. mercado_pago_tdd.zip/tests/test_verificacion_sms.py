from main.verificacion_sms import VerificadorSMS

def test_codigo_correcto():
    verificador = VerificadorSMS()
    assert verificador.verificar_codigo("654321") is True

def test_codigo_incorrecto():
    verificador = VerificadorSMS()
    assert verificador.verificar_codigo("000000") is False
