from main.verificacion_correo import VerificadorCorreo

def test_token_valido():
    verificador = VerificadorCorreo()
    assert verificador.verificar("token123") is True

def test_token_expirado():
    verificador = VerificadorCorreo()
    assert verificador.verificar("expirado") is False
