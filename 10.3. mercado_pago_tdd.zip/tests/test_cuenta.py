from main.cuenta import Cuenta

def test_cuenta_activada_correctamente():
    cuenta = Cuenta()
    cuenta.activar(verificado_correo=True, verificado_sms=True)
    assert cuenta.esta_activada is True

def test_cuenta_no_activada_si_falta_verificacion():
    cuenta = Cuenta()
    cuenta.activar(verificado_correo=True, verificado_sms=False)
    assert cuenta.esta_activada is False
