from main.registro import RegistroUsuario

def test_registro_valido():
    servicio = RegistroUsuario()
    assert servicio.registrar("Juan", "juan@correo.com", "Clave123!") is True

def test_email_invalido():
    servicio = RegistroUsuario()
    assert servicio.registrar("Juan", "correo_invalido", "Clave123!") is False

def test_password_debil():
    servicio = RegistroUsuario()
    assert servicio.registrar("Juan", "juan@correo.com", "123") is False
