class VerificadorSMS:
    def verificar_codigo(self, codigo):
        return codigo == "654321"
