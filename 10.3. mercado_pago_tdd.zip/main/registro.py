import re

class RegistroUsuario:
    def registrar(self, nombre, email, password):
        if not self._validar_email(email):
            return False
        if not self._validar_password(password):
            return False
        return True

    def _validar_email(self, email):
        return re.match(r"[^@]+@[^@]+\.[^@]+", email) is not None

    def _validar_password(self, password):
        return len(password) >= 8 and any(c.isdigit() for c in password)
