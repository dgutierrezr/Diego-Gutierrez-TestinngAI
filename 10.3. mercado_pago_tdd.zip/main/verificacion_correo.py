class VerificadorCorreo:
    def verificar(self, token):
        return token == "token123"
