class Cuenta:
    def __init__(self):
        self.esta_activada = False

    def activar(self, verificado_correo, verificado_sms):
        if verificado_correo and verificado_sms:
            self.esta_activada = True
        else:
            self.esta_activada = False
